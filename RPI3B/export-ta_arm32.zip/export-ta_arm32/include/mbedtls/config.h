/* SPDX-License-Identifier: BSD-2-Clause */
/* Copyright (c) 2018, Linaro Limited */
#ifdef __KERNEL__
#include <mbedtls_config_kernel.h>
#else
#include <mbedtls_config_uta.h>
#endif
